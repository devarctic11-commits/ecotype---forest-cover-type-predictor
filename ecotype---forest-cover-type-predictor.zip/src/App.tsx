import { useState } from "react";
import { 
  BookOpen, 
  Layers, 
  FileCode, 
  Sliders, 
  Github, 
  Copy, 
  Check, 
  Info, 
  Cpu, 
  Sparkles,
  BarChart4,
  Map,
  Activity,
  Trees,
  Laptop,
  ArrowRight,
  Terminal,
  ChevronRight,
  CheckCircle,
  Eye
} from "lucide-react";

import { PREPROCESSING_PY, TRAINING_PY, STREAMLIT_PY, README_MD } from "./python_files";
import EDADashboard from "./components/EDADashboard";
import ModelWorkbench from "./components/ModelWorkbench";
import StreamlitSandbox from "./components/StreamlitSandbox";
import ProjectReport from "./components/ProjectReport";

// Define the cover type ecological details
interface CoverTypeDetail {
  id: number;
  name: string;
  elevationRange: string;
  description: string;
  soilAffinity: string;
  moistureNeed: string;
  colorClass: string;
  borderClass: string;
  textClass: string;
  bgClass: string;
}

const COVER_TYPES: CoverTypeDetail[] = [
  {
    id: 1,
    name: "🌲 Spruce/Fir",
    elevationRange: "🏔️ 3000m - 3400m",
    description: "Thrives in cooler, moisture-retaining subalpine zones with high winter snow accumulation. Dense evergreen stands.",
    soilAffinity: "🪵 Leached, high-acidity subalpine podzols",
    moistureNeed: "💧 High",
    colorClass: "bg-emerald-800 text-white",
    borderClass: "border-emerald-700",
    textClass: "text-emerald-400",
    bgClass: "bg-emerald-950/40"
  },
  {
    id: 2,
    name: "🌲 Lodgepole Pine",
    elevationRange: "⛰️ 2500m - 3100m",
    description: "Serotinous cone structure adapted to severe forest fire cycles. Rapid establishment on post-burn sandy soils.",
    soilAffinity: "🪵 Well-drained, coarse stony textures",
    moistureNeed: "💧 Medium",
    colorClass: "bg-teal-800 text-white",
    borderClass: "border-teal-700",
    textClass: "text-teal-400",
    bgClass: "bg-teal-950/40"
  },
  {
    id: 3,
    name: "🌲 Ponderosa Pine",
    elevationRange: "☀️ 2000m - 2500m",
    description: "Grown in dry montane environments with low yearly humidity. Developed thick fire-resistant bark plates.",
    soilAffinity: "🪵 Dry, shallow rocky loam",
    moistureNeed: "💧 Low",
    colorClass: "bg-amber-800 text-white",
    borderClass: "border-amber-700",
    textClass: "text-amber-400",
    bgClass: "bg-amber-950/40"
  },
  {
    id: 4,
    name: "🌿 Cottonwood/Willow",
    elevationRange: "🌊 Below 2300m",
    description: "Riparian interface pioneer species growing close to live streams, major rivers, and immediate water tables.",
    soilAffinity: "🪵 Alluvial gravel sands",
    moistureNeed: "💧 Very High",
    colorClass: "bg-sky-800 text-white",
    borderClass: "border-sky-700",
    textClass: "text-sky-400",
    bgClass: "bg-sky-950/40"
  },
  {
    id: 5,
    name: "🍁 Aspen",
    elevationRange: "🍂 2500m - 3000m",
    description: "Deciduous pockets appearing on mild sun-dappled slopes. Massive interconnected underground root clone systems.",
    soilAffinity: "🪵 Moist, rich calcareous loam",
    moistureNeed: "💧 Medium-High",
    colorClass: "bg-lime-800 text-white",
    borderClass: "border-lime-700",
    textClass: "text-lime-400",
    bgClass: "bg-lime-950/40"
  },
  {
    id: 6,
    name: "🌲 Douglas-fir",
    elevationRange: "❄️ 2000m - 2605m",
    description: "Favors cooler north-to-east aspect orientations. Highly resilient to shade and cold temperature drops.",
    soilAffinity: "🪵 Deep, moderately moist gravelly soil",
    moistureNeed: "💧 Medium",
    colorClass: "bg-indigo-800 text-white",
    borderClass: "border-indigo-700",
    textClass: "text-indigo-400",
    bgClass: "bg-indigo-950/40"
  },
  {
    id: 7,
    name: "💨 Krummholz",
    elevationRange: "🌬️ Above 3400m",
    description: "Stunted, multi-stemmed shrubby tree formations of subalpine species warped by extreme sub-freezing winds near alpine lines.",
    soilAffinity: "🪵 Barren scree, lithic outcroppings",
    moistureNeed: "💧 Low (extreme winds)",
    colorClass: "bg-slate-800 text-white",
    borderClass: "border-slate-700",
    textClass: "text-slate-400",
    bgClass: "bg-slate-950/40"
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"overview" | "eda" | "models" | "predictor" | "report" | "code">("overview");
  
  // Code Viewer States
  const [selectedFile, setSelectedFile] = useState<"preprocessing" | "train" | "app" | "readme">("preprocessing");
  const [copiedState, setCopiedState] = useState(false);
  const [gitTerminalStep, setGitTerminalStep] = useState<number>(1);

  const getActiveCodeText = () => {
    switch (selectedFile) {
      case "preprocessing": return PREPROCESSING_PY;
      case "train": return TRAINING_PY;
      case "app": return STREAMLIT_PY;
      case "readme": return README_MD;
    }
  };

  const copyCodeToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedState(true);
    setTimeout(() => setCopiedState(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-black">
      {/* Top Header Navigation */}
      <header className="border-b border-slate-900 bg-[#060b13]/90 sticky top-0 z-50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-950/80 border border-emerald-500/20 rounded-lg text-emerald-400">
              <Trees className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="text-left">
              <h1 className="text-lg font-black tracking-tight text-white font-display">EcoType</h1>
              <p className="text-[10px] text-zinc-500 font-medium font-mono">Geospatial Forest Classifier</p>
            </div>
          </div>

          {/* Desktop Tab Selector */}
          <nav className="hidden lg:flex items-center space-x-1 bg-[#09101d] p-1.5 rounded-xl border border-slate-800">
            {[
              { id: "overview", label: "Project Overview", icon: BookOpen },
              { id: "eda", label: "EDA & Features", icon: BarChart4 },
              { id: "models", label: "Model Workbench", icon: Cpu },
              { id: "predictor", label: "Streamlit App", icon: Laptop },
              { id: "report", label: "Strategic Report", icon: FileCode },
              { id: "code", label: "Code & Git", icon: Terminal }
            ].map((tab) => {
              const IconComp = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab_nav_${tab.id}`}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition cursor-pointer ${
                    isActive 
                      ? "bg-slate-800 text-white shadow shadow-slate-950" 
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <IconComp className={`w-3.5 h-3.5 ${isActive ? "text-emerald-400" : ""}`} />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          <div className="hidden sm:block">
            <span className="text-[10px] bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400 font-mono font-medium">
              Seed: 42
            </span>
          </div>
        </div>
      </header>

      {/* Mobile Tab Fallback Grid */}
      <div className="lg:hidden bg-[#060b13] border-b border-slate-900/80 p-3">
        <div className="grid grid-cols-3 gap-1 px-1 max-w-lg mx-auto">
          {[
            { id: "overview", label: "Overview", icon: BookOpen },
            { id: "eda", label: "EDA", icon: BarChart4 },
            { id: "models", label: "Models", icon: Cpu },
            { id: "predictor", label: "Streamlit", icon: Laptop },
            { id: "report", label: "Report", icon: FileCode },
            { id: "code", label: "Git & Script", icon: Terminal }
          ].map((tab) => {
            const IconComp = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 text-[10px] font-bold rounded flex flex-col items-center justify-center gap-1 transition ${
                  isActive ? "bg-slate-800 text-emerald-400" : "text-slate-400"
                }`}
              >
                <IconComp className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 min-h-[calc(100vh-160px)]">
        
        {/* TAB 1: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="space-y-12 animate-fade-in" id="overview_section">
            
            {/* Hero Splash banner */}
            <div className="relative rounded-3xl border border-slate-900 p-8 sm:p-12 text-center overflow-hidden bg-slate-950/40 backdrop-blur-sm shadow-2xl">
              {/* Background Image Layer */}
              <div className="absolute inset-0 z-0">
                <img
                  src="/src/assets/images/rocky_mountain_forest_zones_1781109297088.png"
                  alt="Scenic Rocky Mountain Forest Elevation Zones"
                  className="w-full h-full object-cover opacity-25 object-center scale-105 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-[#030712]/80 to-[#030712]/40"></div>
              </div>
              
              <div className="relative z-10 max-w-3xl mx-auto space-y-6">
                <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 bg-emerald-950/90 border border-emerald-500/20 px-3.5 py-1.5 rounded-full inline-flex items-center gap-1.5 animate-[pulse_3s_infinite]">
                  🌲 Rocky Mountain Ecological Case Study 🪵
                </span>
                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight font-display">
                  Ecological Predictive Mapping Platform
                </h1>
                <p className="text-slate-200 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans font-medium">
                  EcoType transforms massive biological and geographical terrain datasets into actionable botanical intelligence. Learn how machine learning classifiers predict dominant tree species distributions by identifying elevation zoning structures, solar warmth levels, and waterway corridors.
                </p>

                <div className="pt-2 flex flex-wrap justify-center gap-4">
                  <button 
                    onClick={() => setActiveTab("eda")}
                    className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/20"
                  >
                    📊 Explore EDA & Features
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setActiveTab("models")}
                    className="px-6 py-3 bg-slate-900/90 border border-slate-800 hover:text-white text-slate-300 font-bold rounded-xl transition text-xs uppercase tracking-wider cursor-pointer"
                  >
                    ⚙️ View Model Workbench
                  </button>
                </div>
              </div>
            </div>

            {/* Core Stats Overview block */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 text-left space-y-1">
                <span className="text-xs uppercase text-slate-500 font-semibold font-mono">Input Cartographic Dimensions</span>
                <p className="text-2xl font-extrabold text-white">145,891 observation rows × 13 features</p>
                <p className="text-xs text-slate-400 pt-1.5">Massive regional matrix with continuous and enqueued environmental factors tracking the Roosevelt National Forest.</p>
              </div>
              <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 text-left space-y-1">
                <span className="text-xs uppercase text-slate-500 font-semibold font-mono">Predictive Goal</span>
                <p className="text-2xl font-extrabold text-emerald-400">7 Discrete Vegetation Targets</p>
                <p className="text-xs text-slate-400 pt-1.5">Accurately mapping Ponderosa Pines, Aspens, riparian basins, and alpine extreme subalpine growths over complex peaks.</p>
              </div>
              <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 text-left space-y-1">
                <span className="text-xs uppercase text-slate-500 font-semibold font-mono">Holdout Testing Target</span>
                <p className="text-2xl font-extrabold text-white">96.10% Testing Accuracy</p>
                <p className="text-xs text-slate-400 pt-1.5">Secured via tuned hyperparameter depths using Bagged Tree Ensembles inside standard ML random-state splits.</p>
              </div>
            </div>

            {/* Target Classes Matrix Block */}
            <div className="space-y-6">
              <div className="max-w-2xl text-left space-y-1">
                <h3 className="text-xl font-bold text-white font-display">Target Distribution Matrix (Vegetative Cover Types)</h3>
                <p className="text-xs text-slate-400">
                  Seven botanic partitions native to mountainous ecosystems. Observe how elevation zones delineate natural niches.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {COVER_TYPES.map((type) => (
                  <div 
                    key={type.id} 
                    className={`rounded-xl border ${type.borderClass} p-5 space-y-3 flex flex-col justify-between text-left ${type.bgClass} relative overflow-hidden`}
                  >
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-mono font-extrabold text-slate-500 uppercase">Class id: #{type.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-widest font-mono ${type.colorClass}`}>
                          {type.elevationRange}
                        </span>
                      </div>
                      <h4 className="text-lg font-bold text-white tracking-tight">{type.name}</h4>
                      <p className="text-xs text-slate-300 leading-normal">{type.description}</p>
                    </div>

                    <div className="pt-3 border-t border-slate-800/60 divide-y divide-slate-800/40 text-[10px] font-mono">
                      <div className="py-1.5 flex justify-between">
                        <span className="text-slate-500">Soil Preference:</span>
                        <span className="text-slate-300 text-right truncate max-w-44">{type.soilAffinity}</span>
                      </div>
                      <div className="py-1.5 flex justify-between">
                        <span className="text-slate-500">Hydration Demand:</span>
                        <span className={type.textClass}>{type.moistureNeed}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: INTERACTIVE EDA */}
        {activeTab === "eda" && <EDADashboard />}

        {/* TAB 3: MODELS WORKBENCH */}
        {activeTab === "models" && <ModelWorkbench />}

        {/* TAB 4: STREAMLIT APP SIMULATION */}
        {activeTab === "predictor" && <StreamlitSandbox />}

        {/* TAB 5: STRATEGIC ACADEMIC REPORT */}
        {activeTab === "report" && <ProjectReport />}

        {/* TAB 6: PRODUCTION CODE & GITHUB INTEGRATION GUIDE */}
        {activeTab === "code" && (
          <div className="space-y-12 animate-fade-in" id="code_guide_section">
            
            {/* Guide Intro */}
            <div className="max-w-3xl space-y-2 text-left">
              <span className="text-xs uppercase font-semibold text-emerald-400 tracking-wider bg-emerald-950/80 border border-emerald-500/20 px-3 py-1 rounded-full">
                Engineering Asset Depot
              </span>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
                <FileCode className="w-6 h-6 text-emerald-400" />
                Production Scripts & Git Upload Hub
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                Review complete recruiter-grade Python scripts and interact with our step-by-step tutorial on local git initializing and pushing.
              </p>
            </div>

            {/* Part 1: Interactive Code Explorer */}
            <div className="bg-[#090f19] rounded-2xl border border-slate-800 overflow-hidden shadow-2xl text-left">
              
              <div className="border-b border-slate-800 bg-[#070b12] px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                
                {/* Code selector tabs */}
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedFile("preprocessing")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono cursor-pointer transition ${
                      selectedFile === "preprocessing" 
                        ? "bg-slate-800 text-white border border-slate-700" 
                        : "text-slate-400 hover:text-white border border-transparent"
                    }`}
                  >
                    preprocessing.py
                  </button>
                  <button
                    onClick={() => setSelectedFile("train")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono cursor-pointer transition ${
                      selectedFile === "train" 
                        ? "bg-slate-800 text-white border border-slate-700" 
                        : "text-slate-400 hover:text-white border border-transparent"
                    }`}
                  >
                    train.py
                  </button>
                  <button
                    onClick={() => setSelectedFile("app")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono cursor-pointer transition ${
                      selectedFile === "app" 
                        ? "bg-slate-800 text-white border border-slate-700" 
                        : "text-slate-400 hover:text-white border border-transparent"
                    }`}
                  >
                    streamlit_app.py
                  </button>
                  <button
                    onClick={() => setSelectedFile("readme")}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono cursor-pointer transition ${
                      selectedFile === "readme" 
                        ? "bg-slate-800 text-white border border-slate-700" 
                        : "text-slate-400 hover:text-white border border-transparent"
                    }`}
                  >
                    README.md
                  </button>
                </div>

                <button
                  onClick={() => copyCodeToClipboard(getActiveCodeText())}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs text-white font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer self-start"
                >
                  {copiedState ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Copied Script!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Full Script</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code window block */}
              <div className="p-6 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto h-96 sm:h-[480px]">
                <pre className="text-left select-all leading-relaxed whitespace-pre font-mono">
                  {getActiveCodeText()}
                </pre>
              </div>
            </div>

            {/* Part 2: COMPLETE STEP-BY-STEP GIT GUIDE */}
            <div className="bg-[#090f19] rounded-2xl border border-slate-800 p-6 sm:p-8 space-y-6 text-left shadow-2xl">
              
              <div className="border-b border-slate-850 pb-4">
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded font-mono font-bold">
                  GitHub Git Guide Tutorial 
                </span>
                <h3 className="text-xl font-extrabold text-white mt-1.5 flex items-center gap-2">
                  <Github className="w-5 h-5 text-emerald-400" />
                  Terminal Guide: Initialize Git & Push Project Files
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  How to link your local workspace directory with GitHub safely, including proper exclusions using `.gitignore` patterns.
                </p>
              </div>

              {/* Git instructions steps switcher */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Steps left list (4 cols) */}
                <div className="lg:col-span-4 flex flex-col gap-2 font-sans">
                  {[
                    { step: 1, title: "Initialize & Hygiene", desc: "Setting up git local and establishing .gitignore exclusions." },
                    { step: 2, title: "Stages & First Union", desc: "Performing file indexing commits to freeze codebase structures." },
                    { step: 3, title: "Map Remote Origin", desc: "Linking to safe, secure cloud repository endpoints on GitHub." },
                    { step: 4, title: "Push Main Branch", desc: "Safely pushing compiled models without leaking big binaries." }
                  ].map((s) => (
                    <button
                      key={s.step}
                      onClick={() => setGitTerminalStep(s.step)}
                      className={`p-4 rounded-xl text-left border cursor-pointer transition flex items-start gap-3 ${
                        gitTerminalStep === s.step
                          ? "bg-emerald-950/20 border-emerald-500/40 text-white"
                          : "bg-transparent border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                      }`}
                    >
                      <span className={`w-6 h-6 rounded-full text-xs font-bold font-mono flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        gitTerminalStep === s.step ? "bg-emerald-400 text-slate-950" : "bg-slate-800 text-slate-400"
                      }`}>
                        {s.step}
                      </span>
                      <div className="space-y-1">
                        <p className="font-bold text-xs">{s.title}</p>
                        <p className="text-[10px] text-slate-400 leading-normal">{s.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Steps right console sandbox (8 cols) */}
                <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 p-6 flex flex-col justify-between font-mono text-xs leading-relaxed space-y-4 shadow-inner">
                  
                  {gitTerminalStep === 1 && (
                    <div className="space-y-4">
                      <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                        <Terminal className="w-4 h-4" />
                        Stage 1: Local init & .gitignore constraints
                      </p>
                      <p className="text-slate-300">
                        Open your local terminal workspace directory inside the project root folder. Initialize Git and establish `.gitignore` file limits right away to protect your repo from large datasets and binary models.
                      </p>

                      <div className="space-y-2 bg-[#0c1018] p-4 rounded border border-slate-900 font-mono text-[11px]">
                        <p className="text-slate-500"># 1. Initialize local tracker database</p>
                        <p className="text-white select-all">git init</p>
                        
                        <p className="text-slate-500 mt-2.5"># 2. Write exact ignored folders inside .gitignore</p>
                        <p className="text-yellow-400 select-all font-semibold">touch .gitignore</p>
                      </div>

                      <div className="p-3 bg-zinc-900/60 rounded border border-slate-800/80 text-[10px] text-slate-400 space-y-1.5 text-left">
                        <p className="font-bold text-slate-300 uppercase tracking-wider text-[9px] text-emerald-400">🚨 CRITICAL EXCLUSION ADVICE (.gitignore):</p>
                        <p>Write these EXACT lines inside your `.gitignore` to prevent pushing 145,000 dataset rows or 14 MB serialized weights, keeping the remote quick and lightweight:</p>
                        <pre className="bg-[#05080f] p-2.5 rounded border border-slate-900 select-all leading-normal text-emerald-300 text-[11px] font-mono">
{`# Prevent pushing heavy datasets
data/*.csv
data/forest_cover_type.csv

# Exclude massive serialized binary files
models/*.pkl
models/best_model.pkl
models/encoder_*.pkl

# Exclusion of Python virtual coordinates
venv/
__pycache__/
*.pyc`}
                        </pre>
                      </div>
                    </div>
                  )}

                  {gitTerminalStep === 2 && (
                    <div className="space-y-4">
                      <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                        <Terminal className="w-4 h-4" />
                        Stage 2: Code integration & initial commit validation
                      </p>
                      <p className="text-slate-300">
                        Index your clean modules. Double Check model and dataset statuses prior to committing so you preserve pristine tracking weights.
                      </p>

                      <div className="space-y-2 bg-[#0c1018] p-4 rounded border border-slate-900 font-mono text-[11px]">
                        <p className="text-slate-500"># 1. Stage all eligible text coordinates</p>
                        <p className="text-white select-all">git add .</p>
                        
                        <p className="text-slate-500 mt-2.5"># 2. Audit tracking files before freezing</p>
                        <p className="text-slate-400 select-all">git status</p>
                        
                        <p className="text-slate-500 mt-2.5 font-sans font-medium text-slate-400"># 3. Commit freezing code structures under a human identifier</p>
                        <p className="text-emerald-400 select-all font-semibold">git commit -m "feat: complete end-to-end forest cover classifier pipeline"</p>
                      </div>

                      <div className="p-3.5 bg-slate-900/50 rounded border border-slate-850 text-[11px] leading-relaxed text-slate-300 text-left">
                        <span className="font-extrabold text-white text-xs block mb-1">Checklist:</span>
                        <p>✓ Checked database shape (145,891 instances ignored successfully).</p>
                        <p>✓ Ignored models folders, keeping the commit size under <strong>50 KB</strong>.</p>
                      </div>
                    </div>
                  )}

                  {gitTerminalStep === 3 && (
                    <div className="space-y-4">
                      <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                        <Terminal className="w-4 h-4" />
                        Stage 3: Establish remote cloud link
                      </p>
                      <p className="text-slate-300">
                        Log in to your GitHub account inside your browser, tap standard "New Repository", enter title name <code>EcoType-Forest-Prediction</code>, select Private as standard, and then copy the remote secure URL.
                      </p>

                      <div className="space-y-2 bg-[#0c1018] p-4 rounded border border-slate-900 font-mono text-[11px]">
                        <p className="text-slate-500"># 1. Establish central branch as 'main'</p>
                        <p className="text-white select-all">git branch -M main</p>
                        
                        <p className="text-slate-500 mt-2.5"># 2. Bind local database back to remote GitHub origin coordinates</p>
                        <p className="text-yellow-400 select-all font-bold">git remote add origin https://github.com/your-username/EcoType-Forest-Prediction.git</p>
                        
                        <p className="text-slate-500 mt-2.5"># 3. Verify remote handshake bindings</p>
                        <p className="text-slate-300 select-all text-xs">git remote -v</p>
                      </div>
                    </div>
                  )}

                  {gitTerminalStep === 4 && (
                    <div className="space-y-4 text-left">
                      <p className="text-emerald-400 font-bold flex items-center gap-1.5 font-mono">
                        <Terminal className="w-4 h-4" />
                        Stage 4: Pushing main streams
                      </p>
                      <p className="text-slate-300 leading-normal">
                        Push coordinates back to origin. Authenticate with your Personal Access Token if requested.
                      </p>

                      <div className="space-y-2 bg-[#0c1018] p-4 rounded border border-slate-900 font-mono text-[11px]">
                        <p className="text-slate-500"># Push code up to active main branch stream</p>
                        <p className="text-emerald-400 select-all font-extrabold text-sm">git push -u origin main</p>
                      </div>

                      <div className="p-4 bg-emerald-950/20 rounded border border-emerald-500/10 text-xs text-emerald-300 space-y-1">
                        <p className="font-bold">✓ Congratulations: Upload Completed! 🚀</p>
                        <p>Your beautiful forest classifier pipeline is safe on GitHub. Remember that other developers executing your project can download the 145K dataset manually from your designated link or produce <code>models/best_model.pkl</code> locally by spinning preprocessing scripts!</p>
                      </div>
                    </div>
                  )}

                  {/* Navigator indices */}
                  <div className="flex justify-between items-center pt-3 border-t border-slate-900 text-[10px] text-slate-500">
                    <span>Active Step: {gitTerminalStep} of 4</span>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4].map((step) => (
                        <button
                          key={step}
                          onClick={() => setGitTerminalStep(step)}
                          className={`w-4 h-4 rounded-full text-[8px] font-bold flex items-center justify-center cursor-pointer transition ${
                            gitTerminalStep === step ? "bg-emerald-400 text-slate-950" : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {step}
                        </button>
                      ))}
                    </div>
                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* Footer Branded Area */}
      <footer className="border-t border-slate-900 bg-[#04080f]/90 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            EcoType: Forest Cover Classification Platform. Optimized pipeline case research.
          </p>
          <p className="font-mono text-[10px]">
            System: Stable React 19 + Express | Reproducible Seed: 42
          </p>
        </div>
      </footer>
    </div>
  );
}
