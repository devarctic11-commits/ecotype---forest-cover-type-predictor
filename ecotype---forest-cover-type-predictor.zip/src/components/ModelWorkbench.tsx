import { useState } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from "recharts";
import { 
  Cpu, 
  Award, 
  Save, 
  Search, 
  SlidersHorizontal, 
  CheckCircle, 
  AlertCircle,
  TrendingUp,
  Download,
  Flame,
  Info
} from "lucide-react";
import { BASELINE_MODELS, CLASSIFICATION_REPORTS, CONFUSION_MATRICES, SPECIES_LABELS } from "../data/modelData";

export default function ModelWorkbench() {
  const [selectedModel, setSelectedModel] = useState<string>("Random Forest (Optimized)");
  const [activeMatrixCell, setActiveMatrixCell] = useState<{ r: number; c: number; val: number } | null>({ r: 0, c: 1, val: 1.8 });

  // Tuning parameters state
  const [estimators, setEstimators] = useState<number>(200);
  const [maxDepth, setMaxDepth] = useState<number>(20);
  const [minSplit, setMinSplit] = useState<number>(5);
  const [isTuning, setIsTuning] = useState<boolean>(false);
  const [tuningStep, setTuningStep] = useState<string>("");
  const [tuneScore, setTuneScore] = useState<number | null>(null);

  // Serialization simulator states
  const [isSerializing, setIsSerializing] = useState<boolean>(false);
  const [serializedFiles, setSerializedFiles] = useState<string[]>([]);
  const [finishedSerializing, setFinishedSerializing] = useState<boolean>(false);

  // Trigger Hyperparameter Tuning Simulator
  const handleRandomizedSearchCV = () => {
    setIsTuning(true);
    setTuneScore(null);
    const steps = [
      "Configuring 3-Fold Stratified Cross-Validation on resampled training sets...",
      `Assembling RandomizedSearchCV grid (n_estimators: ${estimators}, max_depth: ${maxDepth}, min_samples_split: ${minSplit})...`,
      "Evaluating Fold 1/3: Parameter set 1 (Gini, sqrt features) -> Acc: 94.8%",
      "Evaluating Fold 2/3: Parameter set 2 (Entropy, log2 features) -> Acc: 95.3%",
      "Evaluating Fold 3/3: Parameter set 3 (Gini, log2 features) -> Acc: 96.1%",
      "Compiling final Out-Of-Fold calculations and selecting elite estimator structures..."
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setTuningStep(steps[currentStep]);
        currentStep++;
      } else {
        clearInterval(interval);
        // Calculate a score slightly adjusted from base RF depending on sliders for high fidelity
        const bonusEstimators = (estimators - 100) / 10000;
        const depthPenalty = maxDepth === 5 ? -0.05 : (maxDepth === 10 ? -0.01 : 0);
        const finalScore = parseFloat((0.9610 + bonusEstimators + depthPenalty).toFixed(4));
        setTuneScore(finalScore);
        setIsTuning(false);
      }
    }, 750);
  };

  // Trigger Serialization
  const handleSerialization = () => {
    setIsSerializing(true);
    setFinishedSerializing(false);
    setSerializedFiles([]);

    const steps = [
      { file: "best_model.pkl", size: "14.2 MB", desc: "Tuned Random Forest composite trees serialized via joblib compression." },
      { file: "encoder_wilderness_area.pkl", size: "4.8 KB", desc: "LabelEncoder fitting map mapping Wilderness labels [Rawah, Neota, Comanche Peak, Cache la Poudre]." },
      { file: "encoder_soil_type.pkl", size: "12.6 KB", desc: "LabelEncoder mapping for categorical Geological classes 1-40." }
    ];

    let index = 0;
    const interval = setInterval(() => {
      if (index < steps.length) {
        setSerializedFiles(prev => [...prev, `${steps[index].file} (${steps[index].size}) - ${steps[index].desc}`]);
        index++;
      } else {
        clearInterval(interval);
        setIsSerializing(false);
        setFinishedSerializing(true);

        // Real browser trigger to download simulated zip
        const element = document.createElement("a");
        const file = new Blob([
          `EcoType Model Pipeline State Export Asset\n` +
          `==========================================\n` +
          `Timestamp: 2026-06-10T16:26:00Z\n` +
          `Est. Validation Accuracy: ${tuneScore || 0.9610}\n` +
          `Artifact Contains:\n` +
          `- /models/best_model.pkl\n` +
          `- /models/encoder_wilderness_area.pkl\n` +
          `- /models/encoder_soil_type.pkl`
        ], {type: "text/plain"});
        element.href = URL.createObjectURL(file);
        element.download = "ecotype_model_assets.zip";
        document.body.appendChild(element);
        element.click();
      }
    }, 1000);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="model_workbench_main">
      {/* Tab intro with decorative generated eco-ml model image */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#070d17] border border-slate-800/60 rounded-2xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="lg:col-span-8 space-y-3.5 text-left">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-400 bg-emerald-950/85 border border-emerald-500/20 px-3.5 py-1.5 rounded-full inline-flex items-center gap-1.5">
            ⚙️ Supervised Optimization Workbench 🧬
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2 font-display">
            <Cpu className="w-6 h-6 text-emerald-400" />
            Model Training Arena & Hyperparameter Tuning
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            Benchmark baseline classifier models, run randomized cross-validation searches to optimize depth structures, and serialize final weights & encoding parameters alongside confusion matrix and accuracy summaries.
          </p>
        </div>
        <div className="lg:col-span-4 relative rounded-xl border border-slate-800/80 overflow-hidden group shadow-lg aspect-[4/3] bg-slate-950">
          <img 
            src="/src/assets/images/ecological_ml_model_1781109317493.png" 
            alt="Ecological Machine Learning brain model network" 
            className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-all duration-700" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent"></div>
          <span className="absolute bottom-2 right-2 text-[8px] font-mono bg-emerald-950/90 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded tracking-widest uppercase shadow">
            🧠 ECO_PIPELINE_ACTIVE 🛰️
          </span>
        </div>
      </div>

      {/* Row 1: Model Comparison Chart (5 baseline models) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Baseline Bar Chart (8 cols on lg) */}
        <div className="lg:col-span-8 bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              1. 5-Model Performance Comparison (Baseline)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Observe Holdout Training vs Evaluation accuracies. Decisive trees overfit badly; Random Forest offers stable optimal generalizations.
            </p>
          </div>

          <div className="h-64 sm:h-80 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={BASELINE_MODELS}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <XAxis dataKey="name" stroke="#64748b" style={{ fontSize: 9 }} />
                <YAxis stroke="#64748b" style={{ fontSize: 10 }} domain={[0.6, 1.0]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#090f19", border: "1px solid #1e293b", borderRadius: "8px" }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Legend style={{ fontSize: 10 }} />
                <Bar dataKey="trainingAcc" name="Training Accuracy" fill="#1e293b" radius={[4, 4, 0, 0]} stroke="#475569" />
                <Bar dataKey="evalAcc" name="Evaluation (Test) Accuracy" fill="#059669" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Selected model overview (4 cols on lg) */}
        <div className="lg:col-span-4 bg-[#0b1424] rounded-xl border border-emerald-950/40 p-6 flex flex-col justify-between shadow-xl">
          <div className="space-y-4 text-left">
            <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400">Classifiers Selection Hub</span>
            <div className="space-y-1">
              <h4 className="text-lg font-bold text-white tracking-tight">{selectedModel}</h4>
              <p className="text-xs text-slate-400">Selected estimator structure diagnostics</p>
            </div>

            <div className="divide-y divide-slate-800/60 text-xs">
              <div className="py-2.5 flex justify-between font-mono">
                <span className="text-slate-400">Accuracy (Train):</span>
                <span className="font-bold text-slate-200">
                  {BASELINE_MODELS.find(m => m.name === selectedModel)?.trainingAcc}
                </span>
              </div>
              <div className="py-2.5 flex justify-between font-mono">
                <span className="text-slate-400">Accuracy (Test):</span>
                <span className="font-bold text-emerald-400">
                  {BASELINE_MODELS.find(m => m.name === selectedModel)?.evalAcc}
                </span>
              </div>
              <div className="py-2.5 flex justify-between font-mono">
                <span className="text-slate-400">F1 Score (Macro):</span>
                <span className="font-bold text-slate-200">
                  {BASELINE_MODELS.find(m => m.name === selectedModel)?.f1Macro}
                </span>
              </div>
              <p className="py-3 text-xs text-slate-300 leading-relaxed text-left">
                {BASELINE_MODELS.find(m => m.name === selectedModel)?.description}
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-2 pt-4">
            <span className="text-[10px] text-slate-500 uppercase font-bold">Select Active Model for plots:</span>
            <div className="flex flex-wrap gap-1.5 justify-start">
              {["Random Forest (Optimized)", "XGBoost Classifier", "Decision Tree Classifier"].map((mName) => (
                <button
                  key={mName}
                  onClick={() => setSelectedModel(mName)}
                  className={`px-2.5 py-1 text-[10px] font-semibold rounded border transition cursor-pointer ${
                    selectedModel === mName 
                      ? "bg-slate-700 text-white border-slate-600" 
                      : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                  }`}
                >
                  {mName.split(" ")[0]}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Hyperparameter Tuning (RandSearchCV Sandbox) */}
      <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-slate-800/80">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-emerald-400" />
              2. RandomizedSearchCV Tuning Laboratory
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulate randomized grid optimization across critical decision boundaries of our leading Random Forest classifier.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2.5 py-0.5 rounded-full font-semibold">
              K-Folds = 3 Cross-Validation
            </span>
          </div>
        </div>

        {/* Adjust Grid controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          
          <div className="space-y-1.5 text-left">
            <div className="flex justify-between">
              <label className="text-xs text-slate-300 font-medium font-mono">n_estimators</label>
              <span className="text-xs text-emerald-400 font-mono font-bold">{estimators} trees</span>
            </div>
            <input 
              type="range"
              min="50"
              max="300"
              step="50"
              value={estimators}
              onChange={(e) => setEstimators(parseInt(e.target.value))}
              disabled={isTuning}
              className="w-full accent-emerald-500 h-1 text-slate-950"
            />
            <span className="text-[10px] text-zinc-500 block leading-tight">Density of decision trees under parallel baggers.</span>
          </div>

          <div className="space-y-1.5 text-left">
            <div className="flex justify-between">
              <label className="text-xs text-slate-300 font-medium font-mono">max_depth</label>
              <span className="text-xs text-emerald-400 font-mono font-bold">{maxDepth} nodes</span>
            </div>
            <input 
              type="range"
              min="5"
              max="25"
              step="5"
              value={maxDepth}
              onChange={(e) => setMaxDepth(parseInt(e.target.value))}
              disabled={isTuning}
              className="w-full accent-emerald-500 h-1 text-slate-950"
            />
            <span className="text-[10px] text-zinc-500 block leading-tight">Depth boundaries. Bounding depth stops overfitting.</span>
          </div>

          <div className="space-y-1.5 text-left">
            <div className="flex justify-between">
              <label className="text-xs text-slate-300 font-medium font-mono font-normal">min_samples_split</label>
              <span className="text-xs text-emerald-400 font-mono font-semibold">{minSplit} instances</span>
            </div>
            <input 
              type="range"
              min="2"
              max="10"
              step="1"
              value={minSplit}
              onChange={(e) => setMinSplit(parseInt(e.target.value))}
              disabled={isTuning}
              className="w-full accent-emerald-500 h-1 text-slate-950"
            />
            <span className="text-[10px] text-zinc-500 block leading-tight">Samples required to split internal node vectors.</span>
          </div>

          {/* Trigger Button */}
          <div className="flex flex-col justify-end">
            <button
              onClick={handleRandomizedSearchCV}
              disabled={isTuning}
              className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition flex items-center justify-center gap-2 cursor-pointer"
            >
              {isTuning ? (
                <>
                  <div className="animate-spin rounded-full h-3.5 w-3.5 border-2 border-slate-950 border-t-transparent"></div>
                  <span>Searching...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 text-slate-950" />
                  <span>Iterate Tuning Search</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Progress box or score details */}
        {(isTuning || tuneScore) && (
          <div className="bg-slate-950/80 rounded-lg p-5 border border-slate-800 space-y-3.5 animate-fade-in font-mono text-xs">
            {isTuning ? (
              <div className="space-y-2 text-left">
                <p className="text-amber-500 animate-pulse font-semibold">⚡ Tuning Pipeline Active ⚡</p>
                <p className="text-slate-300">{tuningStep}</p>
                <div className="w-full bg-slate-900 h-1 rounded overflow-hidden">
                  <div className="h-full bg-amber-500 w-2/3 animate-[pulse_1s_infinite]"></div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
                <div className="space-y-1">
                  <p className="text-emerald-400 font-bold flex items-center gap-1.5 text-sm">
                    <CheckCircle className="w-4 h-4" />
                    Tuning Completed Successfully!
                  </p>
                  <p className="text-slate-300 text-xs text-left">
                    Search found optimized hyperparameter parameters: n_estimators={estimators}, max_depth={maxDepth}, min_samples_split={minSplit}.
                  </p>
                </div>

                <div className="bg-slate-900 px-4 py-2.5 rounded border border-slate-800 text-center flex-shrink-0 min-w-40">
                  <span className="text-[10px] text-slate-500 block uppercase tracking-wider">Optimized Accuracy</span>
                  <span className="text-emerald-400 font-extrabold text-lg mt-0.5 block">{tuneScore}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Row 3: Evaluation Details (Confusion Matrix & Classification Report) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Confusion Matrix (7 cols) */}
        <div className="lg:col-span-7 bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white">3. Multi-Class Confusion Matrix Heatmap</h3>
            <p className="text-xs text-slate-400 mt-0.5 leading-normal">
              Heat map evaluating predictive confusions across classes (values shown in percentage). Hover or click cells.
            </p>
          </div>

          <div className="pt-2">
            {/* Grid Container */}
            <div className="grid grid-cols-8 gap-1 text-center font-mono text-[9px] sm:text-xs">
              {/* Empty upper-left corner */}
              <div className="aspect-square bg-transparent"></div>
              {/* Column labels */}
              {Array.from({ length: 7 }, (_, idx) => (
                <div key={`col-${idx}`} className="aspect-square flex items-center justify-center font-bold text-[8px] text-slate-400 rotate-45 sm:rotate-0">
                  C{idx+1}
                </div>
              ))}

              {/* Rows */}
              {CONFUSION_MATRICES[selectedModel]?.map((row, rIdx) => (
                <div className="contents" key={`row-${rIdx}`}>
                  {/* Row Label */}
                  <div className="aspect-square flex items-center justify-end font-bold text-[8px] text-slate-400 pr-1 truncate font-mono">
                    C{rIdx+1}
                  </div>

                  {/* Row Values */}
                  {row.map((val, cIdx) => {
                    const isDiagonal = rIdx === cIdx;
                    let cellBg = "bg-slate-900 border-slate-800 hover:scale-105";

                    if (isDiagonal) {
                      cellBg = "bg-emerald-950 border-emerald-500/50 text-emerald-400 font-extrabold";
                    } else if (val > 2.0) {
                      cellBg = "bg-rose-950/40 border-rose-500/20 text-rose-300 hover:scale-105";
                    }

                    const isCellSelected = activeMatrixCell?.r === rIdx && activeMatrixCell?.c === cIdx;

                    return (
                      <button
                        key={`cell-${rIdx}-${cIdx}`}
                        onClick={() => setActiveMatrixCell({ r: rIdx, c: cIdx, val: val })}
                        className={`aspect-square rounded border flex items-center justify-center cursor-pointer transition text-[9px] sm:text-xs ${cellBg} ${
                          isCellSelected ? "ring-2 ring-emerald-400 scale-10 z-10" : ""
                        }`}
                      >
                        {val < 1 && val > 0 ? val.toFixed(1) : val.toFixed(0)}%
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Matrix Help notes */}
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 mt-4 text-[7px] sm:text-[9px] font-mono text-slate-500 text-left border-t border-slate-800/50 pt-2">
              {SPECIES_LABELS.map((lbl, idx) => (
                <span key={idx}>C{idx+1}: {lbl.split("/")[0]}</span>
              ))}
            </div>

            {/* Cell Diagnostic explanation */}
            {activeMatrixCell && (
              <div className="bg-[#0b121e] rounded-lg p-3.5 border border-slate-800 text-xs text-left text-slate-300 mt-4 leading-relaxed font-mono flex items-start gap-2.5 shadow">
                <Info className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white font-bold mb-1">
                    Matrix Point: True {SPECIES_LABELS[activeMatrixCell.r]} x Pred {SPECIES_LABELS[activeMatrixCell.c]}
                  </h4>
                  <p>
                    {activeMatrixCell.r === activeMatrixCell.c ? (
                      `Perfect Classification! ${activeMatrixCell.val}% accuracy rate correctly mapping physical coordinates.`
                    ) : (
                      `Ecosystem Confusion! ${activeMatrixCell.val}% misclassification occurs here. This is typically driven by standard altimetric zoning compete margins, where ${SPECIES_LABELS[activeMatrixCell.r]} and ${SPECIES_LABELS[activeMatrixCell.c]} battle across shared soil parameters.`
                    )}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Classification Report (5 cols) */}
        <div className="lg:col-span-5 bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center justify-between col-span-1 border-b border-slate-800 pb-2">
              <span>4. Classification Matrix Metrics</span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono font-normal">
                Recall & F1 evaluation
              </span>
            </h3>
          </div>

          <div className="overflow-x-auto pt-1">
            <table className="w-full text-left text-xs text-slate-300 border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-mono text-[10px]">
                  <th className="pb-2">Forest Species</th>
                  <th className="pb-2">Precision</th>
                  <th className="pb-2">Recall</th>
                  <th className="pb-2">F1-Score</th>
                  <th className="pb-2 text-right">Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-[11px] font-mono">
                {Object.entries(CLASSIFICATION_REPORTS[selectedModel] || CLASSIFICATION_REPORTS["Random Forest (Optimized)"]).map(([species, entry]) => {
                  const isAvg = species === "Macro Average";
                  return (
                    <tr key={species} className={isAvg ? "text-emerald-400 font-bold border-t border-slate-700/80 pt-2" : "text-slate-300"}>
                      <td className="py-2.5 font-sans font-medium">{species}</td>
                      <td className="py-2.5">{(entry.precision).toFixed(2)}</td>
                      <td className="py-2.5">{(entry.recall).toFixed(2)}</td>
                      <td className="py-2.5 font-bold">{(entry.f1Score).toFixed(2)}</td>
                      <td className="py-2.5 text-right text-slate-400">{entry.support.toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Row 4: Best Model Selection and Serialization panel */}
      <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-6 sm:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 shadow-xl items-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        {/* Crown & Model (7 cols) */}
        <div className="md:col-span-7 space-y-4 text-left">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-900/40 border border-emerald-500/30 text-emerald-400 rounded-lg">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 uppercase tracking-widest font-bold">
                Optimized Best Model 選定 
              </span>
              <h4 className="text-xl font-bold text-white mt-1">Random Forest Classifier (Ensembled)</h4>
            </div>
          </div>

          <p className="text-xs text-slate-200 leading-relaxed max-w-xl">
            Our benchmarks confirm Random Forest generalized coordinates with superior safety compared to multi-boosting structures. By capping outliers under IQR and packing derived Pythergorean hydrology vectors, our model caps F1 scores above <strong>96.1%</strong>.
          </p>

          <div className="flex flex-wrap gap-4 text-xs font-mono text-emerald-400 font-semibold pt-1">
            <span>✓ Depth bounds: Bounded to 20</span>
            <span>✓ Encoders: Multi-class persisted</span>
            <span>✓ Seed State: Verified 42</span>
          </div>
        </div>

        {/* Compile Card (5 cols) */}
        <div className="md:col-span-5 bg-slate-950/80 rounded-xl border border-slate-800 p-5 space-y-4 flex flex-col justify-between shadow-inner">
          <div className="space-y-1.5 text-left">
            <h5 className="text-sm font-bold text-white flex items-center gap-1.5 font-mono">
              <Save className="w-4 h-4 text-emerald-400" />
              export_model_pipeline()
            </h5>
            <p className="text-[11px] text-slate-400 leading-normal">
              Compiles, packs, and serializes tuned estimators and LabelEncoder fitting parameters to local folder paths.
            </p>
          </div>

          <button
            onClick={handleSerialization}
            disabled={isSerializing}
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold text-xs uppercase tracking-widest rounded-lg transition flex items-center justify-center gap-2 cursor-pointer shadow shadow-emerald-500/20"
          >
            {isSerializing ? (
              <>
                <div className="animate-spin rounded-full h-3.5 w-3.5 border-2 border-slate-950 border-t-transparent"></div>
                <span>Exporting PKLs...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-slate-950" />
                <span>Save Model & Encoders</span>
              </>
            )}
          </button>

          {/* Files created summary list */}
          {serializedFiles.length > 0 && (
            <div className="border-t border-slate-800/80 pt-2.5 text-left text-[10px] font-mono space-y-1.5 text-slate-300">
              {serializedFiles.map((f, idx) => (
                <p key={idx} className="flex items-start gap-1">
                  <span className="text-emerald-400">✓</span>
                  <span>{f}</span>
                </p>
              ))}
              {finishedSerializing && (
                <p className="text-emerald-400 font-bold bg-emerald-950/30 px-2 py-1 rounded mt-1 border border-emerald-500/10 text-center animate-fade-in uppercase tracking-wider text-[9px]">
                  Compressed zip Downloaded! Check local folders.
                </p>
              )}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
