import { useState } from "react";
import { 
  Play, 
  HelpCircle,
  ExternalLink,
  Laptop,
  Compass,
  TrendingDown,
  Info,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Cpu
} from "lucide-react";
import { SimulationInputs } from "../types";

export default function StreamlitSandbox() {
  const [inputs, setInputs] = useState<SimulationInputs>({
    Elevation: 2800,
    Aspect: 180,
    Slope: 15,
    Horizontal_Distance_To_Hydrology: 150,
    Vertical_Distance_To_Hydrology: 30,
    Horizontal_Distance_To_Roadways: 1200,
    Hillshade_9am: 210,
    Hillshade_Noon: 218,
    Hillshade_3pm: 140,
    Horizontal_Distance_To_Fire_Points: 1500,
    Wilderness_Area: "Rawah",
    Soil_Type: "Type 1"
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<any>(null);
  const [errorString, setErrorString] = useState<string | null>(null);

  // Set individual inputs securely
  const handleInputChange = (field: keyof SimulationInputs, value: any) => {
    setInputs(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const executeStreamlitPrediction = async () => {
    setLoading(true);
    setResult(null);
    setErrorString(null);

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ features: inputs })
      });

      if (!response.ok) {
        throw new Error(`API returned status code ${response.status}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error("Streamlit simulation failure:", err);
      setErrorString(`Failed to compile pipeline calculation: ${err.message || err}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="streamlit_sandbox_main">
      {/* Intro block */}
      <div className="max-w-3xl space-y-2">
        <span className="text-xs uppercase font-semibold text-emerald-400 tracking-wider bg-emerald-950/80 border border-emerald-500/20 px-3 py-1 rounded-full">
          Interactive Local Simulation Lab
        </span>
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <Laptop className="w-6 h-6 text-emerald-400" />
          Active Streamlit Application Instance (app.py)
        </h2>
        <p className="text-slate-300 text-sm leading-relaxed">
          The Streamlit interface below is fully live. Modify geo-inputs in the sidebar panel, click the trigger button in the mainframe, and trace calculations piped directly back to our classifier API server.
        </p>
      </div>

      {/* Streamlit Box Container */}
      <div className="bg-[#111] rounded-xl border border-slate-700 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[620px] text-left">
        
        {/* Streamlit Header Bar */}
        <div className="col-span-12 bg-[#262730] border-b border-[#1c1d24] px-4 py-2.5 flex items-center justify-between text-xs font-mono text-slate-300">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-red-500 rounded-full"></span>
            <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full"></span>
            <span className="w-2.5 h-2.5 bg-green-500 rounded-full"></span>
            <span className="ml-2 font-semibold text-slate-100">localhost:8501 (Streamlit App)</span>
          </div>
          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">
            STATUS: ACTIVE PORT 3000
          </span>
        </div>

        {/* Streamlit Sidebar (4 cols on md) */}
        <div className="md:col-span-4 bg-[#f0f2f6] text-[#31333f] border-r border-slate-300 p-5 space-y-5 flex flex-col justify-start max-h-[580px] overflow-y-auto">
          
          <div className="space-y-1">
            <h4 className="text-sm font-extrabold text-slate-900 border-b border-slate-300 pb-2">
              Configuration Panel
            </h4>
            <p className="text-[10px] text-slate-500">Input geographic variables to evaluate Cover_Type:</p>
          </div>

          {/* Elevation Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <label>Elevation (meters)</label>
              <span className="text-emerald-700 font-bold">{inputs.Elevation}m</span>
            </div>
            <input 
              type="range"
              min="1800"
              max="4000"
              value={inputs.Elevation}
              onChange={(e) => handleInputChange("Elevation", parseInt(e.target.value))}
              className="w-full accent-emerald-600 h-1 cursor-pointer bg-slate-300"
            />
            <span className="text-[9px] text-slate-500 block leading-tight">Key altitude zoning limits (1800m - 4000m).</span>
          </div>

          {/* Aspect Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <label>Aspect (degrees)</label>
              <span className="text-emerald-700 font-bold">{inputs.Aspect}°</span>
            </div>
            <input 
              type="range"
              min="0"
              max="360"
              value={inputs.Aspect}
              onChange={(e) => handleInputChange("Aspect", parseInt(e.target.value))}
              className="w-full accent-emerald-600 h-1 cursor-pointer bg-slate-300"
            />
          </div>

          {/* Slope Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <label>Slope (degrees)</label>
              <span className="text-emerald-700 font-bold">{inputs.Slope}°</span>
            </div>
            <input 
              type="range"
              min="0"
              max="60"
              value={inputs.Slope}
              onChange={(e) => handleInputChange("Slope", parseInt(e.target.value))}
              className="w-full accent-emerald-600 h-1 cursor-pointer bg-slate-300"
            />
          </div>

          {/* Wilderness Selection Dropdown */}
          <div className="space-y-1">
            <label className="text-xs font-semibold block">Wilderness Area</label>
            <select 
              value={inputs.Wilderness_Area}
              onChange={(e) => handleInputChange("Wilderness_Area", e.target.value)}
              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-slate-800"
            >
              {["Rawah", "Neota", "Comanche Peak", "Cache la Poudre"].map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          {/* Soil Type Selection Dropdown */}
          <div className="space-y-1">
            <label className="text-xs font-semibold block font-sans">Geological Soil Type</label>
            <select 
              value={inputs.Soil_Type}
              onChange={(e) => handleInputChange("Soil_Type", e.target.value)}
              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-slate-800"
            >
              {Array.from({ length: 40 }, (_, i) => `Type ${i+1}`).map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div className="pt-3 border-t border-slate-300 text-[10px] text-slate-500 font-bold flex flex-col gap-0.5 leading-normal">
            <span>app.py • Streamlit Dev Build</span>
            <span>Made with ❤ under Scikit-Learn</span>
          </div>

        </div>

        {/* Streamlit Mainframe (8 cols on md) */}
        <div className="md:col-span-8 bg-[#ffffff] text-[#31333f] p-6 space-y-6 max-h-[580px] overflow-y-auto">
          
          {/* Header Title mock */}
          <div className="space-y-1 text-center">
            <h1 className="text-2xl font-black text-[#1e3d59]">EcoType</h1>
            <h3 className="text-sm font-bold text-[#17b978]">Forest Cover Type Prediction System</h3>
            <p className="text-[10px] text-slate-500">Live predictive inference pipeline simulation dashboard</p>
            <hr className="border-slate-200 mt-3" />
          </div>

          {/* Mid Row Layout (Numeric Inputs) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="space-y-4">
              <h5 className="text-xs font-extrabold text-slate-800 border-b border-slate-150 pb-1 flex items-center gap-1">
                <span>Infrastructure Indices</span>
              </h5>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">Distance to Water Table (m)</label>
                <input 
                  type="number"
                  min="0"
                  max="1500"
                  value={inputs.Horizontal_Distance_To_Hydrology}
                  onChange={(e) => handleInputChange("Horizontal_Distance_To_Hydrology", parseInt(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">Vertical Distance to Water (m)</label>
                <input 
                  type="number"
                  min="-200"
                  max="500"
                  value={inputs.Vertical_Distance_To_Hydrology}
                  onChange={(e) => handleInputChange("Vertical_Distance_To_Hydrology", parseInt(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">Distance to Intersecting Roads (m)</label>
                <input 
                  type="number"
                  min="0"
                  max="8000"
                  value={inputs.Horizontal_Distance_To_Roadways}
                  onChange={(e) => handleInputChange("Horizontal_Distance_To_Roadways", parseInt(e.target.value) || 0)}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h5 className="text-xs font-extrabold text-slate-800 border-b border-slate-150 pb-1 flex items-center gap-1">
                <span>Solar Radiation Indices</span>
              </h5>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">9:00 AM Hillshade (0-255)</label>
                <input 
                  type="number"
                  min="0"
                  max="255"
                  value={inputs.Hillshade_9am}
                  onChange={(e) => handleInputChange("Hillshade_9am", Math.max(0, Math.min(255, parseInt(e.target.value) || 0)))}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">High Noon Hillshade (0-255)</label>
                <input 
                  type="number"
                  min="0"
                  max="255"
                  value={inputs.Hillshade_Noon}
                  onChange={(e) => handleInputChange("Hillshade_Noon", Math.max(0, Math.min(255, parseInt(e.target.value) || 0)))}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>

              <div className="space-y-1 text-xs">
                <label className="font-semibold block text-slate-700">3:00 PM Hillshade (0-255)</label>
                <input 
                  type="number"
                  min="0"
                  max="255"
                  value={inputs.Hillshade_3pm}
                  onChange={(e) => handleInputChange("Hillshade_3pm", Math.max(0, Math.min(255, parseInt(e.target.value) || 0)))}
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
                />
              </div>
            </div>

          </div>

          <div className="space-y-1 text-xs">
            <label className="font-semibold block text-slate-700">Distance to Wildfire ignition point (m)</label>
            <input 
              type="number"
              min="0"
              max="8000"
              value={inputs.Horizontal_Distance_To_Fire_Points}
              onChange={(e) => handleInputChange("Horizontal_Distance_To_Fire_Points", parseInt(e.target.value) || 0)}
              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1 text-xs text-[#31333f]"
            />
          </div>

          {/* Trigger Button */}
          <div className="pt-3">
            <button
              onClick={executeStreamlitPrediction}
              disabled={loading}
              className="w-full py-2.5 bg-[#17b978] hover:bg-[#139c63] disabled:bg-slate-300 text-white font-bold text-sm tracking-wide rounded shadow transition flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Computing Inference vectors...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Generate Cover Type Prediction</span>
                </>
              )}
            </button>
          </div>

          {/* Output Predictions Panel (Mimics Streamlit blocks) */}
          {(result || errorString) && (
            <div className="pt-4 border-t border-slate-200 text-left space-y-4 font-sans animate-fade-in">
              <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-widest font-mono">
                Streamlit Output Streams
              </h4>

              {errorString ? (
                <div className="bg-[#ffebeb] border-l-4 border-red-500 rounded p-4 text-xs text-red-800 font-mono flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <p>{errorString}</p>
                </div>
              ) : (
                <div className="space-y-3.5">
                  {/* Dynamic success block with huge aesthetic emoji badge */}
                  {(() => {
                    let emoji = "🌳";
                    switch (result.predicted_class) {
                      case 1: emoji = "🌲🏔️"; break;
                      case 2: emoji = "🌲🔥"; break;
                      case 3: emoji = "🪵☀️"; break;
                      case 4: emoji = "🌿🌊"; break;
                      case 5: emoji = "🍁🍂"; break;
                      case 6: emoji = "🌲❄️"; break;
                      case 7: emoji = "💨🌬️"; break;
                    }
                    return (
                      <div className="bg-[#eafaf1] border-l-4 border-[#2ecc71] rounded-r-lg p-4 text-[#1b7a43] space-y-3 flex flex-col sm:flex-row items-start sm:items-center gap-4 shadow-sm border border-emerald-100">
                        <div className="p-3 bg-white rounded-xl shadow-inner border border-emerald-150 text-3xl animate-[bounce_1s_ease-out_1]">
                          {emoji}
                        </div>
                        <div className="text-xs sm:text-sm">
                          <p className="font-extrabold text-[#115e3c] tracking-wider uppercase text-[10px] font-mono">st.success: Classification Result parsed!</p>
                          <p className="font-sans text-base text-slate-800 font-bold mt-0.5">
                            Cover_Type {result.predicted_class} — {result.predicted_label}
                          </p>
                          <p className="text-[11px] text-[#2c774d] font-semibold">
                            Eco-ecological niche map match verified
                          </p>
                        </div>
                      </div>
                    );
                  })()}

                  {/* info box style of streamlit */}
                  <div className="bg-[#eef2f7] border-l-4 border-[#3498db] rounded-r p-4 text-[#205b82] space-y-1.5 text-xs">
                    <div className="flex items-center gap-2 font-bold mb-1">
                      <Info className="w-4 h-4 text-[#3498db]" />
                      <span>st.info: Model Certainty Probability Matrix</span>
                    </div>
                    <p className="font-mono text-[11px]">
                      Confidence: <strong>{result.confidence}</strong> | Estimated Probability density: <strong>{Math.round(result.probability * 100)}%</strong>
                    </p>
                    <p className="leading-relaxed bg-white/60 p-3 rounded border border-slate-200 mt-2 font-mono text-[11px] text-[#31333f]">
                      <strong>Dynamic Ecological Breakdown:</strong> {result.reasoning}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
