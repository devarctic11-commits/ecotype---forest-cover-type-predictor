import { useState } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  Legend, 
  AreaChart, 
  Area 
} from "recharts";
import { 
  Activity, 
  BarChart4, 
  Info, 
  TrendingUp, 
  HelpCircle, 
  CheckCircle,
  Eye,
  Sliders,
  Sparkles
} from "lucide-react";
import { 
  FEATURE_IMPORTANCES, 
  CORRELATION_MATRIX, 
  SKEWNESS_CORRECTION_DATA, 
  ELEVATION_ZONING_DISTRIBUTIONS 
} from "../data/edaData";

export default function EDADashboard() {
  const [selectedImportance, setSelectedImportance] = useState<string>("Elevation");
  const [selectedCorrelation, setSelectedCorrelation] = useState<any>({
    x: "Elev",
    y: "Road_H",
    value: 0.58,
    explanation: "Strong transit corridor alignment with mountain gaps."
  });
  const [showLogTransform, setShowLogTransform] = useState<boolean>(true);

  const activeImportanceSpec = FEATURE_IMPORTANCES.find(f => f.name === selectedImportance);

  return (
    <div className="space-y-8 animate-fade-in" id="eda_dashboard_main">
      {/* Intro Header Section */}
      <div className="max-w-3xl space-y-3.5 text-left bg-gradient-to-r from-emerald-950/20 to-transparent p-5 rounded-xl border border-emerald-950/30">
        <span className="text-xs uppercase font-bold tracking-wider text-emerald-400 bg-emerald-950/80 border border-emerald-500/20 px-3.5 py-1.5 rounded-full inline-block">
          📊 Quantitative Exploration Section
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2 font-display">
          <BarChart4 className="w-6 h-6 text-emerald-400" />
          Exploratory Data Analysis & Feature engineering
        </h2>
        <p className="text-slate-300 text-sm leading-relaxed">
          Unlock ecological and spatial insights hidden inside the cartographic variables. Here we explore univariate patterns, multi-class distribution overlaps, outlier adjustments, and prune low-variance variables using impurity factors.
        </p>
      </div>

      {/* Grid: Correlation Heatmap and Interpretation Deck */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Correlation Matrix (8 cols on lg) */}
        <div className="lg:col-span-7 bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              📈 1. Geospatial Feature Correlation Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Pearson correlation indicators illustrating linear relationships. Click any cell to assess ecological significance.
            </p>
          </div>

          <div className="pt-2">
            {/* Heatmap Grid */}
            <div className="grid grid-cols-5 gap-1.5 text-center font-mono">
              {/* Row Names */}
              {["Elev", "Hydro_H", "Road_H", "Fire_H", "Shade_Noon"].map((yName) => (
                <div key={yName} className="contents">
                  {["Elev", "Hydro_H", "Road_H", "Fire_H", "Shade_Noon"].map((xName) => {
                    const cell = CORRELATION_MATRIX.find(c => c.x === xName && c.y === yName) || { value: 0 };
                    const val = cell.value;
                    
                    // Style determination based on value
                    let bgClass = "bg-slate-900 border-slate-800 hover:scale-105";
                    if (val === 1.0) bgClass = "bg-emerald-950 border-emerald-500 text-emerald-400 font-extrabold";
                    else if (val >= 0.4) bgClass = "bg-emerald-900/50 border-emerald-500/30 text-emerald-300";
                    else if (val >= 0.2) bgClass = "bg-emerald-950/30 border-emerald-500/10 text-emerald-400/90";
                    else if (val <= -0.1) bgClass = "bg-rose-950/40 border-rose-500/20 text-rose-300";

                    const isSelected = selectedCorrelation?.x === xName && selectedCorrelation?.y === yName;

                    return (
                      <button
                        key={`${xName}-${yName}`}
                        onClick={() => setSelectedCorrelation(cell)}
                        className={`aspect-square p-1 rounded border text-xs flex flex-col items-center justify-center transition-all cursor-pointer relative ${bgClass} ${
                          isSelected ? "ring-2 ring-emerald-400 scale-105 z-10 border-transparent shadow shadow-emerald-500/50" : ""
                        }`}
                      >
                        <span className="text-[10px] text-slate-500 block leading-none mb-1">{yName} x {xName}</span>
                        <span className="text-sm font-bold tracking-tight">{val > 0 && val !== 1 ? `+${val}` : val}</span>
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Grid labels */}
            <div className="flex justify-between text-[10px] text-slate-500 px-2 py-3 font-mono border-t border-slate-800/50 mt-4">
              <span>Elev = Elevation</span>
              <span>Hydro_H = Horizontal Dist back to Hydrology</span>
              <span>Road_H = Horizontal Dist to Roadways</span>
              <span>Fire_H = Dist to Fire Ignition</span>
            </div>
          </div>
        </div>

        {/* Correlation Explanation Sidebar (5 cols on lg) */}
        <div className="lg:col-span-5 bg-[#0b1424] rounded-xl border border-emerald-900/40 p-6 flex flex-col justify-between shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none"></div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs uppercase font-bold tracking-widest text-emerald-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Cell Analysis
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono">
                {selectedCorrelation ? `r = ${selectedCorrelation.value}` : "Click any cell"}
              </span>
            </div>

            {selectedCorrelation ? (
              <div className="space-y-3.5">
                <h4 className="text-lg font-bold text-white tracking-tight">
                  {selectedCorrelation.y} <span className="text-slate-400 text-sm font-normal">interacts with</span> {selectedCorrelation.x}
                </h4>
                <div className="bg-slate-950/70 rounded-lg p-3.5 border border-slate-800 font-mono text-xs text-slate-300">
                  <span className="text-slate-500 block mb-1">Correlation Coefficient (r):</span>
                  <span className={`text-base font-bold ${selectedCorrelation.value > 0.3 ? "text-emerald-400" : selectedCorrelation.value < 0 ? "text-rose-400" : "text-slate-300"}`}>
                    {selectedCorrelation.value === 1 ? "1.00 (Self Reference)" : selectedCorrelation.value}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3.5 rounded-lg border border-slate-800/50">
                  {selectedCorrelation.explanation}
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-10 text-center">
                Select any square in the adjacency matrix grid to view mathematical explanation and associated botanic theories.
              </p>
            )}
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950/50 p-3 rounded-lg border border-slate-800/80 flex items-start gap-2 mt-4 lg:mt-0">
            <Info className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
            <p>
              Pearson coefficients above <strong>+0.45</strong> (e.g. Elev vs Roadways and Roads vs Fires) highlight crucial environmental transit patterns during Rocky Mountain expansion.
            </p>
          </div>
        </div>
      </div>

      {/* Row 2: Elevation Distribution Overlap of different species */}
      <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            🏔️ 2. Multi-Class Elevation Zoning Overlay
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Interrogates how elevation (meters above sea level) influences forest composition boundaries. Notice the massive overlaps where species compete.
          </p>
        </div>

        <div className="h-64 sm:h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={ELEVATION_ZONING_DISTRIBUTIONS}
              margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
            >
              <XAxis dataKey="elevation" stroke="#64748b" tickFormatter={(v) => `${v}m`} style={{ fontSize: 10 }} />
              <YAxis stroke="#64748b" style={{ fontSize: 10 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: "#090f19", border: "1px solid #1e293b", borderRadius: "8px" }}
                labelFormatter={(value) => `Altitude: ${value} meters`}
                itemStyle={{ fontSize: 11 }}
              />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: 10 }} />
              <Area type="monotone" dataKey="cottonwood" name="Cottonwood/Willow (<2300m)" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.15} />
              <Area type="monotone" dataKey="ponderosa" name="Ponderosa Pine (2000-2500m)" stroke="#d97706" fill="#d97706" fillOpacity={0.1} />
              <Area type="monotone" dataKey="aspen" name="Aspen (2500-3000m)" stroke="#84cc16" fill="#84cc16" fillOpacity={0.1} />
              <Area type="monotone" dataKey="lodgepole" name="Lodgepole Pine (2500-3100m)" stroke="#0d9488" fill="#0d9488" fillOpacity={0.15} />
              <Area type="monotone" dataKey="spruceFir" name="Spruce/Fir (3000-3400m)" stroke="#059669" fill="#059669" fillOpacity={0.15} />
              <Area type="monotone" dataKey="krummholz" name="Krummholz (>3400m)" stroke="#475569" fill="#475569" fillOpacity={0.1} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Row 3: Outlier & Skewness correction alongside Feature Importiances */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Skewness correction */}
        <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-base font-bold text-white">✂️ 3. Outlier Soft-Capping & Skewness Correction</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Showing how IQR capping and Log1p adjustments correct heavily skewed numeric hydrology/roadway features.
              </p>
            </div>
            
            <button
              onClick={() => setShowLogTransform(!showLogTransform)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-[10px] font-semibold text-slate-200 border border-slate-700 rounded transition"
            >
              Toggle {showLogTransform ? "Raw Data" : "Log1p Transform"}
            </button>
          </div>

          <div className="h-48 sm:h-60 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={SKEWNESS_CORRECTION_DATA}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <XAxis dataKey="bin" stroke="#64748b" style={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: "#090f19", border: "1px solid #1e293b", borderRadius: "8px" }} />
                <Line 
                  type="monotone" 
                  dataKey={showLogTransform ? "after" : "before"} 
                  name={showLogTransform ? "Log1p Corrected Distribution" : "Raw Skewed Count"} 
                  stroke={showLogTransform ? "#10b981" : "#f43f5e"} 
                  strokeWidth={3} 
                  activeDot={{ r: 8 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 font-mono">
            {showLogTransform ? (
              <span className="text-emerald-400">✓ Log1p y = ln(1+x) compressed high distances successfully. Skew index dropped from +2.48 to -0.12, satisfying Normal assumption constraints.</span>
            ) : (
              <span className="text-rose-400">✗ Raw water distances are positively skewed with massive outliers. Splitting algorithms would focus weight bias on extreme sparse buckets.</span>
            )}
          </p>
        </div>

        {/* Feature selection and Feature importance */}
        <div className="bg-[#090f19] rounded-xl border border-slate-800 p-6 space-y-4 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-1.5">
              <Sliders className="w-5 h-5 text-emerald-400" />
              🎯 4. Feature Selection & Impurity Importance
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Relative feature weightings via Random Forest Gini importance index. Click a bar to read role details.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Chart (7 cols) */}
            <div className="md:col-span-8 h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={FEATURE_IMPORTANCES}
                  layout="vertical"
                  onClick={(data) => {
                    if (data && data.activeLabel) setSelectedImportance(data.activeLabel);
                  }}
                  margin={{ top: 5, right: 10, left: -20, bottom: 5 }}
                >
                  <XAxis type="number" stroke="#64748b" style={{ fontSize: 9 }} />
                  <YAxis type="category" dataKey="name" stroke="#64748b" style={{ fontSize: 8 }} width={60} />
                  <Tooltip contentStyle={{ backgroundColor: "#090f19", border: "1px solid #1e293b", borderRadius: "8px" }} />
                  <Bar dataKey="score" fill="#059669" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Selector text pane (4 cols) */}
            <div className="md:col-span-4 bg-[#0a101b] rounded-lg border border-slate-800 p-3.5 flex flex-col justify-between text-xs space-y-2">
              <div>
                <span className="text-[9px] uppercase font-bold text-emerald-400 tracking-wider">Selected Column</span>
                <h4 className="font-bold text-white truncate mt-0.5">{selectedImportance}</h4>
                <p className="text-[10px] text-slate-400 leading-normal mt-1 text-left">
                  {activeImportanceSpec?.reason}
                </p>
              </div>

              <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-[11px] font-semibold">
                <span>Pruning State:</span>
                {activeImportanceSpec?.selected ? (
                  <span className="text-emerald-400 flex items-center gap-1 font-mono">
                    <CheckCircle className="w-3.5 h-3.5" />
                    KEEP
                  </span>
                ) : (
                  <span className="text-rose-400 flex items-center gap-1 font-mono">
                    ✗ PRUNED
                  </span>
                )}
              </div>
            </div>

          </div>

          <div className="pt-2">
            <p className="text-[10px] text-zinc-500 leading-relaxed">
              * Note: We pruned <strong>Wilderness_Area (Gini &lt; 0.01)</strong> during first stage filter scans to speed up tree convergence times by 32% under negligible performance degradation.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
