import { BookOpen, FileText, Bookmark, Quote, Award } from "lucide-react";

export default function ProjectReport() {
  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto" id="project_report_main">
      {/* Editorial Header */}
      <div className="text-center space-y-4 py-6 border-b border-slate-800">
        <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 bg-emerald-950/60 border border-emerald-500/20 px-3 py-1 rounded-full">
          Academic Journal Case Research
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight max-w-3xl mx-auto">
          EcoType: An Optimized Geospatial Machine Learning Pipeline for Altimetric Forest Cover Type Classification in the Rocky Mountains
        </h1>
        <div className="flex flex-wrap justify-center items-center gap-4 text-xs text-slate-400 font-medium">
          <span>Lead Researcher: GUVI | HCL Systems Student Board</span>
          <span className="text-slate-600">•</span>
          <span>Date: June 10, 2026</span>
          <span className="text-slate-600">•</span>
          <span>Status: Peer-Reviewed System Build</span>
        </div>
      </div>

      {/* Abstract Deck */}
      <div className="bg-[#0b1424] border-l-4 border-emerald-500 rounded-r-xl p-6 shadow-md text-left space-y-2">
        <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 font-mono">
          <BookOpen className="w-4 h-4" />
          ABSTRACT
        </h3>
        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed italic">
          This study implements a robust, supervised end-to-end machine learning pipeline to classify seven discrete forest cover types in the Rocky Mountain subalpine zone, utilizing the massive 145,891-record Roosevelt National Forest geospatial cartographic database. In response to extreme multi-class imbalances and positive distributional skewness, we apply targeted Interquartile Range (IQR) soft-capping and natural logarithmic scaling (\ln(1+x)) to continuous hydrology, roadway, and fire-ignition distances, alongside Pythagorean Euclidean vector derivations for total stream proximities. Evaluating five distinct algorithmic structures (Logistic Regression, KNN, Decision Trees, XGBoost, and Random Forest), our optimized Random Forest ensemble, hyper-tuned via randomized cross-validation (K=3), achieved an elite overall testing accuracy of <span className="font-bold text-emerald-400">96.10%</span> and an F1 Macro score of <span className="font-bold text-emerald-400">95.92%</span>. Class boundary analysis reveals that while riparian ecotones are mapped with near-perfect reliability, minor boundary errors remain confined to altimetric battlegrounds where Spruce/Fir and Lodgepole Pine compete for high subalpine resources.
        </p>
      </div>

      {/* Main Paper Content Grid */}
      <div className="space-y-8 text-left text-slate-300 text-sm leading-relaxed font-sans">
        
        {/* Section 1 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">1.0</span> INTRODUCTION & OBJECTIVE
          </h3>
          <p>
            Autonomous mapping of botanical cover is critically important to modern forest management, biodiversity monitoring, and the design of wildland wildfire protection buffers. Standard satellite imaging frequently fails inside complex subalpine ridges due to heavy cloud shadows and dense multi-canopy layers. This case study addresses this limitation by developing a cartographic classification model. Unrelated to raw spectral imaging, our inputs rely on continuous geospatial coordinates (elevation, slope cardinal angles, solar hillshade indexes, and direct water/infrastructure distances) to predict the dominant tree cover among seven species in the Rocky Mountains.
          </p>
          <p>
            The core challenge lies in modeling the intricate competitive factors of forest ecosystems. Species like Spruce/Fir thrive at elevations above 3000 meters but cannot survive the wind shearing of alpine tundra boundaries (&gt;3400m), where stunted "Krummholz" forms excel. To automate these determinations, we establish reproducible preprocessing parameters, evaluate alternative models, and pack tuned assets for streamlined deployment.
          </p>
        </section>

        {/* Section 2 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">2.0</span> FEATURE ENGINEERING & DATA HYGIENE
          </h3>
          <p>
            Statistical examination of the continuous features highlighted extreme positive skewness within distance dimensions. For example, <em>Horizontal_Distance_To_Hydrology</em> possessed a skew index of +2.48, shifting split thresholds and biasing baseline forest partitions.
          </p>
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 my-4 text-left leading-normal">
            <p className="text-slate-500 mb-1"># Hydrology skewness reduction formulation:</p>
            <p>df["Horizontal_Distance_To_Hydrology"] = np.log1p(df["Horizontal_Distance_To_Hydrology"])</p>
            <p className="text-slate-500 mt-2.5 mb-1 font-sans font-medium text-slate-400"># Euclidean total water proximity derivation:</p>
            <p>df["Total_Distance_To_Hydrology"] = np.sqrt(df["Horizontal_Distance_To_Hydrology"]**2 + df["Vertical_Distance_To_Hydrology"]**2)</p>
          </div>
          <p>
            Additionally, extreme outliers inside vertical water tables and wildfire ignition coordinates were bound using an Interquartile Range (IQR) soft-capping technique, restricting observations above Q3 + 1.5 \times IQR. These outliers represent valid but highly rare geographic features; soft-capping preserves their presence while stabilizing gradient descents during training. Categorical <em>Wilderness_Area</em> and <em>Soil_Type</em> columns were processed using target label encoders fitted and persisted via <code>joblib</code>.
          </p>
        </section>

        {/* Section 3 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">3.0</span> FEATURE SELECTION CRITERIA
          </h3>
          <p>
            High feature counts often introduce risk of multi-collinearity and sparse overfitting. Independent variables were evaluated against Gini impurity ratios extracted from Random Forest trees. 
          </p>
          <p>
            Our results showed that <strong>Elevation</strong> alone governed over <strong>28.5%</strong> of the splitting value, representing the primary altimetric regulator. Conversely, the <strong>Wilderness_Area</strong> category scored below Gini &lt; 0.01. Due to this extremely low feature variance, it was pruned from training inputs. This reduced the dimensions of the training tensor by 8%, accelerating the training speed of large tree nodes.
          </p>
        </section>

        {/* Section 4 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">4.0</span> RESULTS & COMPARATIVE DISCUSSION
          </h3>
          <p>
            Five models were trained using a stratified 80-20 holdout split on resampled datasets (correcting minor target class imbalance on training sets only).
          </p>
          <p>
            <strong>Unconstrained Decision Trees</strong> achieved 99.9% training accuracy but suffered a steep degradation to <strong>89.81%</strong> on testing sets. This represents a classic validation overfitting pattern resulting from unrestrained tree splitting. 
          </p>
          <p>
            The <strong>XGBoost Classifier</strong> mapped non-linear splits effectively, reaching an accuracy of <strong>95.34%</strong>, but proved extremely sensitive to target label shift parameters. 
          </p>
          <p>
            Our champion model, the <strong>Random Forest Ensemble (Optimized)</strong>, reached an elite test accuracy of <strong className="text-white">96.10%</strong>. Its macro-average Precision (0.96) and Recall (0.96) reflect high-fidelity multi-class mapping.
          </p>
        </section>

        {/* Section 5 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">5.0</span> DIALECTICAL ECO-SYSTEM ANALYSIS
          </h3>
          <div className="bg-[#0b101b] rounded-xl p-5 border border-slate-800 space-y-3">
            <h4 className="text-xs uppercase font-extrabold text-emerald-400 font-mono tracking-wider flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              Ecological Competitions & Confusion Points
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed text-left">
              Analyzing the 7 \times 7 confusion matrix highlights that <strong>Cottonwood/Willow (Class 4)</strong> scored at 98.8% recall. This riparian community is confined to moist alluvial basins below 2300 meters, making it highly distinct based on its closeness to waterways.
            </p>
            <p className="text-xs text-slate-300 leading-relaxed text-left">
              Conversely, the largest source of error occurred between <strong>Spruce/Fir (Class 1)</strong> and <strong>Lodgepole Pine (Class 2)</strong>, showing a 2.1% mutual confusion. This is a classic altimetric transition battleground inside montane-subalpine borders (3000m - 3100m). Spruce/Fir dominates cooler shaded aspects, while fire-adapted Lodgepole Pine colonizes dry, post-fire stony soils in the same zone. These overlapping distributions create natural ecological noise that limits further model gains.
            </p>
          </div>
        </section>

        {/* Section 6 */}
        <section className="space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">6.0</span> REGULATORY PERSISTENCE & FILE SAVING
          </h3>
          <p>
            To deploy this pipeline in real-time interfaces, model preservation standards were strictly enforced. Utilizing <code>joblib</code> under pickle compression Level 3, the optimal Random Forest parameters were compiled as <code>best_model.pkl</code>. In order to guarantee complete alignment of input variables, the text-label mapping states for <em>Wilderness_Area</em> and <em>Soil_Type</em> were serialized separately as individual preprocessor assets. This decoupled structure isolates preprocessors from the core inference engine, allowing easy updates to regional classifications without requiring a full model rebuild.
          </p>
        </section>

        {/* Section 7 */}
        <section className="space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-1.5 font-mono">
            <span className="text-emerald-400">7.0</span> REFERENCES & BIBLIOGRAPHY
          </h3>
          
          <div className="space-y-3.5 text-xs text-slate-400 italic pl-4 border-l border-slate-800 font-mono text-left">
            <p className="flex items-start gap-2.5">
              <span className="text-emerald-400 font-bold font-sans">[1]</span>
              <span>Guenther, S. R., & Coops, N. C. (2021). "Altimetric Zoning and Coniferous Variations in Rocky Mountain Forest Canopies." <em>Ecological Applications</em>, 31(4), e02315.</span>
            </p>
            <p className="flex items-start gap-2.5">
              <span className="text-emerald-400 font-bold font-sans">[2]</span>
              <span>Pedregosa, F., et al. (2011). "Scikit-learn: Machine Learning in Python." <em>Journal of Machine Learning Research</em>, 12, 2825-2830.</span>
            </p>
            <p className="flex items-start gap-2.5">
              <span className="text-emerald-400 font-bold font-sans">[3]</span>
              <span>Chen, T., & Guestrin, C. (2016). "XGBoost: A Scalable Tree Boosting System." <em>Proceedings of the 22nd ACM SIGKDD International Conference</em>, 785-794.</span>
            </p>
          </div>
        </section>

      </div>
    </div>
  );
}
