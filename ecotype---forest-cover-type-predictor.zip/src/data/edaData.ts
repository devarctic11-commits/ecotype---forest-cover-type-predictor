import { FeatureImportance, CorrelationCell } from "../types";

export const FEATURE_IMPORTANCES: FeatureImportance[] = [
  {
    name: "Elevation",
    score: 0.285,
    selected: true,
    reason: "Strict altitude zoning boundaries govern Rocky Mountain tree growth limits and temperature margins."
  },
  {
    name: "Horizontal_Distance_To_Roadways",
    score: 0.148,
    selected: true,
    reason: "Reflects transit corridors, logging history, and human-induced land clearance patterns."
  },
  {
    name: "Horizontal_Distance_To_Fire_Points",
    score: 0.125,
    selected: true,
    reason: "Measures wildfire frequency and environmental buffer distances which drive pine tree serotiny cycles."
  },
  {
    name: "Horizontal_Distance_To_Hydrology",
    score: 0.087,
    selected: true,
    reason: "Horizontal separation to streams, establishing critical moisture corridors for riparian plants."
  },
  {
    name: "Hillshade_9am",
    score: 0.068,
    selected: true,
    reason: "Governs early morning moisture evaporation and micro-climatic solar warming, especially on eastern exposures."
  },
  {
    name: "Hillshade_Noon",
    score: 0.059,
    selected: true,
    reason: "High noon solar irradiance index. Correlates directly with dry aspect tree stress."
  },
  {
    name: "Vertical_Distance_To_Hydrology",
    score: 0.057,
    selected: true,
    reason: "Altitude offsets from water tables, mapping drainage dynamics on steep mountains."
  },
  {
    name: "Aspect",
    score: 0.052,
    selected: true,
    reason: "Cardinal direction exposure (degrees). Determines structural shadowing and temperature zones."
  },
  {
    name: "Hillshade_3pm",
    score: 0.049,
    selected: true,
    reason: "Evaluates hot afternoon solar stressors and forest moisture depletion curves on western slopes."
  },
  {
    name: "Soil_Type (Encoded)",
    score: 0.038,
    selected: true,
    reason: "Matches key rock lithologies and rich loam contents with specific species soil preferences."
  },
  {
    name: "Slope",
    score: 0.024,
    selected: true,
    reason: "Steepness gradient. Controls soil depth, erosion rate, and water runoff speed variables."
  },
  {
    name: "Wilderness_Area (Encoded)",
    score: 0.008,
    selected: false,
    reason: "Pruned during stage-1 feature selection due to extremely low feature variance across sub-regions."
  }
];

export const CORRELATION_MATRIX: CorrelationCell[] = [
  { x: "Elev", y: "Elev", value: 1.0, explanation: "Perfect self-correlation parameter." },
  { x: "Elev", y: "Hydro_H", value: 0.31, explanation: "Higher subalpine soils generally possess deeper vertical groundwater tables." },
  { x: "Elev", y: "Road_H", value: 0.58, explanation: "Mountainous transits follow natural valleys peaking near sub-summits." },
  { x: "Elev", y: "Fire_H", value: 0.34, explanation: "Highest peaks experience less direct human ignition but elevated lightning." },
  { x: "Elev", y: "Shade_Noon", value: -0.15, explanation: "Thinner atmospheres at high altitudes create specialized shading index offsets." },

  { x: "Hydro_H", y: "Elev", value: 0.31, explanation: "Hydrology horizontal patterns widen and expand at higher basin locations." },
  { x: "Hydro_H", y: "Hydro_H", value: 1.0, explanation: "Perfect self-correlation." },
  { x: "Hydro_H", y: "Road_H", value: 0.08, explanation: "Modern logistics run parallel to riverways at lower elevations." },
  { x: "Hydro_H", y: "Fire_H", value: 0.16, explanation: "Areas closer to rivers hold high moisture, diminishing active fire zones." },
  { x: "Hydro_H", y: "Shade_Noon", value: 0.05, explanation: "No relevant direct ecological correlation." },

  { x: "Road_H", y: "Elev", value: 0.58, explanation: "Strong transit corridor alignment with mountain gaps." },
  { x: "Road_H", y: "Hydro_H", value: 0.08, explanation: "Road paths avoid immediate wet alluvial channels for foundation safety." },
  { x: "Road_H", y: "Road_H", value: 1.0, explanation: "Perfect self-correlation." },
  { x: "Road_H", y: "Fire_H", value: 0.49, explanation: "Road proximity corresponds directly with increased human-caused fire starts." },
  { x: "Road_H", y: "Shade_Noon", value: -0.04, explanation: "Irrelevant aspect-level shading correlation." },

  { x: "Fire_H", y: "Elev", value: 0.34, explanation: "Dry lightning risks concentrate on elevated subalpine ridges." },
  { x: "Fire_H", y: "Hydro_H", value: 0.16, explanation: "Hydrology buffers slow or arrest wild fires." },
  { x: "Fire_H", y: "Road_H", value: 0.49, explanation: "Heavy correlation between human road transits and historic ignitions." },
  { x: "Fire_H", y: "Fire_H", value: 1.0, explanation: "Perfect self-correlation." },
  { x: "Fire_H", y: "Shade_Noon", value: -0.02, explanation: "No direct meteorological bearing." },

  { x: "Shade_Noon", y: "Elev", value: -0.15, explanation: "High altitudes receive severe solar incidence which limits tree height shading." },
  { x: "Shade_Noon", y: "Hydro_H", value: 0.05, explanation: "No direct water interaction." },
  { x: "Shade_Noon", y: "Road_H", value: -0.04, explanation: "No significant topography alignment." },
  { x: "Shade_Noon", y: "Fire_H", value: -0.02, explanation: "No physical correlation." },
  { x: "Shade_Noon", y: "Shade_Noon", value: 1.0, explanation: "Perfect self-correlation." },
];

export const SKEWNESS_CORRECTION_DATA = [
  { bin: "0-100m", before: 45000, after: 12000 },
  { bin: "100-300m", before: 28000, after: 18000 },
  { bin: "300-500m", before: 18000, after: 20000 },
  { bin: "500-800m", before: 9000, after: 21000 },
  { bin: "800-1200m", before: 3500, after: 19000 },
  { bin: "1200m+", before: 800, after: 15500 }
];

export const ELEVATION_ZONING_DISTRIBUTIONS = [
  { elevation: 1800, spruceFir: 0, lodgepole: 0, ponderosa: 15, cottonwood: 85, aspen: 0, douglas: 30, krummholz: 0 },
  { elevation: 2100, spruceFir: 0, lodgepole: 0, ponderosa: 42, cottonwood: 60, aspen: 10, douglas: 55, krummholz: 0 },
  { elevation: 2400, spruceFir: 5, lodgepole: 15, ponderosa: 80, cottonwood: 12, aspen: 35, douglas: 78, krummholz: 0 },
  { elevation: 2700, spruceFir: 15, lodgepole: 62, ponderosa: 20, cottonwood: 0, aspen: 90, douglas: 45, krummholz: 0 },
  { elevation: 3000, spruceFir: 48, lodgepole: 88, ponderosa: 0, cottonwood: 0, aspen: 65, douglas: 10, krummholz: 0 },
  { elevation: 3300, spruceFir: 92, lodgepole: 30, ponderosa: 0, cottonwood: 0, aspen: 12, douglas: 0, krummholz: 25 },
  { elevation: 3600, spruceFir: 20, lodgepole: 0, ponderosa: 0, cottonwood: 0, aspen: 0, douglas: 0, krummholz: 95 },
  { elevation: 3900, spruceFir: 0, lodgepole: 0, ponderosa: 0, cottonwood: 0, aspen: 0, douglas: 0, krummholz: 99 }
];
