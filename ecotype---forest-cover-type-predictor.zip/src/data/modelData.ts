import { ModelMetric, EvaluationReport } from "../types";

export const BASELINE_MODELS: ModelMetric[] = [
  {
    name: "Random Forest (Optimized)",
    trainingAcc: 0.9852,
    evalAcc: 0.9610,
    f1Macro: 0.9592,
    precision: 0.9602,
    recall: 0.9583,
    description: "Multi-tree bootstrap bagging ensemble. Delivers elite generalization with balanced variance control and highly stable decision structures."
  },
  {
    name: "XGBoost Classifier",
    trainingAcc: 0.9741,
    evalAcc: 0.9534,
    f1Macro: 0.9515,
    precision: 0.9525,
    recall: 0.9507,
    description: "Gradient boosted decision trees. Excels in finding complex non-linear splitting structures but requires strict shifted coordinate inputs."
  },
  {
    name: "K-Nearest Neighbors",
    trainingAcc: 0.9410,
    evalAcc: 0.9125,
    f1Macro: 0.9080,
    precision: 0.9069,
    recall: 0.9094,
    description: "Distance-based clustering. Effective for resolving high-density pockets but struggles with memory overhead on large cartographic matrices."
  },
  {
    name: "Decision Tree Classifier",
    trainingAcc: 0.9992,
    evalAcc: 0.8981,
    f1Macro: 0.8967,
    precision: 0.8951,
    recall: 0.8984,
    description: "Single unconstrained tree. Heavily prone to overfitting, splitting nodes down to individual leaf samples if not strictly bounded."
  },
  {
    name: "Logistic Regression",
    trainingAcc: 0.7245,
    evalAcc: 0.7212,
    f1Macro: 0.6953,
    precision: 0.7021,
    recall: 0.6891,
    description: "Linear classification baseline. High bias but low variance. Struggles to represent complex high-dimensional non-linear terrain zoning transitions."
  }
];

export const CLASSIFICATION_REPORTS: Record<string, Record<string, EvaluationReport>> = {
  "Random Forest (Optimized)": {
    "Spruce/Fir": { precision: 0.96, recall: 0.97, f1Score: 0.96, support: 28140 },
    "Lodgepole Pine": { precision: 0.97, recall: 0.95, f1Score: 0.96, support: 32420 },
    "Ponderosa Pine": { precision: 0.94, recall: 0.96, f1Score: 0.95, support: 14200 },
    "Cottonwood/Willow": { precision: 0.98, recall: 0.99, f1Score: 0.98, support: 2500 },
    "Aspen": { precision: 0.95, recall: 0.93, f1Score: 0.94, support: 6200 },
    "Douglas-fir": { precision: 0.93, recall: 0.94, f1Score: 0.94, support: 9800 },
    "Krummholz": { precision: 0.97, recall: 0.98, f1Score: 0.97, support: 8200 },
    "Macro Average": { precision: 0.96, recall: 0.96, f1Score: 0.96, support: 101460 }
  },
  "XGBoost Classifier": {
    "Spruce/Fir": { precision: 0.95, recall: 0.96, f1Score: 0.95, support: 28140 },
    "Lodgepole Pine": { precision: 0.96, recall: 0.94, f1Score: 0.95, support: 32420 },
    "Ponderosa Pine": { precision: 0.93, recall: 0.95, f1Score: 0.94, support: 14200 },
    "Cottonwood/Willow": { precision: 0.97, recall: 0.98, f1Score: 0.97, support: 2500 },
    "Aspen": { precision: 0.94, recall: 0.92, f1Score: 0.93, support: 6200 },
    "Douglas-fir": { precision: 0.92, recall: 0.93, f1Score: 0.92, support: 9800 },
    "Krummholz": { precision: 0.96, recall: 0.97, f1Score: 0.96, support: 8200 },
    "Macro Average": { precision: 0.95, recall: 0.95, f1Score: 0.95, support: 101460 }
  },
  "Decision Tree Classifier": {
    "Spruce/Fir": { precision: 0.90, recall: 0.90, f1Score: 0.90, support: 28140 },
    "Lodgepole Pine": { precision: 0.89, recall: 0.88, f1Score: 0.89, support: 32420 },
    "Ponderosa Pine": { precision: 0.88, recall: 0.89, f1Score: 0.88, support: 14200 },
    "Cottonwood/Willow": { precision: 0.92, recall: 0.94, f1Score: 0.93, support: 2500 },
    "Aspen": { precision: 0.86, recall: 0.87, f1Score: 0.86, support: 6200 },
    "Douglas-fir": { precision: 0.87, recall: 0.86, f1Score: 0.86, support: 9800 },
    "Krummholz": { precision: 0.94, recall: 0.93, f1Score: 0.93, support: 8200 },
    "Macro Average": { precision: 0.89, recall: 0.90, f1Score: 0.89, support: 101460 }
  }
};

export const CONFUSION_MATRICES: Record<string, number[][]> = {
  "Random Forest (Optimized)": [
    [97.2,  1.8,  0.4,  0.0,  0.2,  0.3,  0.1], // Spruce/Fir
    [ 2.1, 95.4,  1.1,  0.0,  0.6,  0.7,  0.1], // Lodgepole
    [ 0.2,  1.3, 96.1,  0.5,  0.1,  1.7,  0.1], // Ponderosa
    [ 0.0,  0.0,  0.4, 98.8,  0.0,  0.8,  0.0], // Cottonwood
    [ 1.5,  3.2,  0.3,  0.0, 93.5,  1.4,  0.1], // Aspen
    [ 0.1,  1.5,  2.8,  0.6,  0.4, 94.2,  0.4], // Douglas-fir
    [ 0.8,  0.2,  0.1,  0.0,  0.1,  0.2, 98.6]  // Krummholz
  ],
  "XGBoost Classifier": [
    [96.1,  2.4,  0.6,  0.0,  0.3,  0.4,  0.2],
    [ 2.6, 94.2,  1.5,  0.0,  0.7,  0.9,  0.1],
    [ 0.4,  1.6, 95.2,  0.6,  0.2,  1.9,  0.1],
    [ 0.0,  0.1,  0.5, 98.1,  0.0,  1.3,  0.0],
    [ 1.8,  3.8,  0.5,  0.0, 92.1,  1.6,  0.2],
    [ 0.3,  1.9,  3.1,  0.8,  0.5, 93.1,  0.3],
    [ 1.1,  0.3,  0.1,  0.0,  0.1,  0.3, 98.1]
  ],
  "Decision Tree Classifier": [
    [90.1,  5.8,  1.5,  0.1,  1.2,  0.9,  0.4],
    [ 6.1, 88.4,  2.4,  0.2,  1.5,  1.3,  0.1],
    [ 1.4,  3.2, 89.1,  1.8,  0.6,  3.6,  0.3],
    [ 0.1,  0.2,  2.2, 94.2,  0.1,  3.1,  0.1],
    [ 3.8,  5.6,  1.2,  0.1, 87.2,  2.0,  0.1],
    [ 1.1,  3.4,  4.8,  1.9,  1.2, 86.4,  1.2],
    [ 2.8,  0.8,  0.5,  0.1,  0.4,  1.5, 93.9]
  ]
};

export const SPECIES_LABELS = [
  "Spruce/Fir",
  "Lodgepole Pine",
  "Ponderosa Pine",
  "Cottonwood/Willow",
  "Aspen",
  "Douglas-fir",
  "Krummholz"
];
