export interface CoverTypeDetail {
  id: number;
  name: string;
  elevationRange: string;
  description: string;
  soilAffinity: string;
  moistureNeed: string;
  colorClass: string;
  borderClass: string;
  textClass: string;
  bgClass: string;
}

export interface FeatureImportance {
  name: string;
  score: number;
  selected: boolean;
  reason: string;
}

export interface CorrelationCell {
  x: string;
  y: string;
  value: number;
  explanation: string;
}

export interface ModelMetric {
  name: string;
  trainingAcc: number;
  evalAcc: number;
  f1Macro: number;
  precision: number;
  recall: number;
  description: string;
}

export interface EvaluationReport {
  precision: number;
  recall: number;
  f1Score: number;
  support: number;
}

export interface SimulationInputs {
  Elevation: number;
  Aspect: number;
  Slope: number;
  Horizontal_Distance_To_Hydrology: number;
  Vertical_Distance_To_Hydrology: number;
  Horizontal_Distance_To_Roadways: number;
  Hillshade_9am: number;
  Hillshade_Noon: number;
  Hillshade_3pm: number;
  Horizontal_Distance_To_Fire_Points: number;
  Wilderness_Area: string;
  Soil_Type: string;
}
